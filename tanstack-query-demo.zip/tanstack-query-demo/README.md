# TanStack Query Demo

A minimal React + Vite project that demonstrates fetching and caching with **@tanstack/react-query**.

## Run locally

```bash
npm install
npm run dev
```

Open the printed local URL (usually `http://localhost:5173`).

## What it shows
- App is wrapped with `QueryClientProvider`
- `Users.jsx` uses `useQuery` to fetch from JSONPlaceholder API
- Basic defaults: `staleTime`, `gcTime`, `retry`, `refetchOnWindowFocus`
- Devtools included
