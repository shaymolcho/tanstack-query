import React from 'react'
import { useQuery } from '@tanstack/react-query'

export default function Users() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['users'],
    queryFn: () =>
      fetch('https://jsonplaceholder.typicode.com/users')
        .then((res) => {
          if (!res.ok) throw new Error('Network response was not ok')
          return res.json()
        })
  })

  if (isLoading) return <p>Loading users…</p>
  if (error) return <p>Oops! {error.message}</p>

  return (
    <ul className="users">
      {data.map((user) => (
        <li key={user.id}>
          <strong>{user.name}</strong> <span>({user.email})</span>
        </li>
      ))}
    </ul>
  )
}
