import React from 'react'
import Users from './Users'

export default function App() {
  return (
    <div className="container">
      <h1>TanStack Query Demo</h1>
      <p>This simple demo fetches users from the JSONPlaceholder API using <code>useQuery</code>.</p>
      <Users />
    </div>
  )
}
